================================================
FOR <filename>.zip
================================================


	a). Save this file to your computer.

	b). Extract the files to a DOS bootable device (such as a bootable USB stick, or CD).

	c). Boot to a DOS prompt and type AMI.BAT filename.xxx.(example AMI.BAT X8DT30.311)

	d). Do not interrupt the process until the flashing is complete.

	e). If the computer pauses, please wait until it starts to program.

	f). Reboot the system by pressing "CTRL+ALT+DEL" .

	g). Press "F1" to the BIOS screen when system reboot and shows the message "Press F1 to go to setup or press F2 to continue.

	h). Press "F9" to "load the default" in the BIOS screen.

	i). Press "F10" to "Save and Exit"
	

** If the BIOS flash failed, you can check the user's manual how to recover your BIOS or contact our RMA dept. to have the bios chip reprogrammed.
This will require shipping the board to our RMA dept. for BIOS reprogramming.  
The RMA dept's email address is rma@supermicro.com


Bios Recovery:

http://www.supermicro.com/about/policies/disclaimer.cfm?url=/manuals/other/AMI_BIOS_Recovery.pdf